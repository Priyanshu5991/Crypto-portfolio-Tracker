async function fetchWallet() {
    const wallet = document.getElementById('walletInput').value.trim();
    if (!wallet) return alert("Enter wallet address");

    document.getElementById('loader').style.display = 'block';
    const res = await fetch('/api/wallet', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ wallet })
    });

    const data = await res.json();
    document.getElementById('loader').style.display = 'none';

    if (data.error) return alert(data.error);

    document.getElementById('walletInfo').innerHTML =
        `<h3>Total Value: $${data.total_value_usd.toFixed(2)}</h3>` +
        data.tokens.map(t => `<p>${t.symbol.toUpperCase()}: ${t.balance} × $${t.price_usd}</p>`).join('');

    fetchPriceChart(data.tokens[0].symbol);
}

async function fetchPriceChart(symbol) {
    const res = await fetch(`/api/price/${symbol}`);
    const data = await res.json();
    const ctx = document.getElementById('priceChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: `${symbol.toUpperCase()} Price (USD)`,
                data: data.prices,
                borderColor: 'rgba(75, 192, 192, 1)',
                tension: 0.1
            }]
        }
    });
}
