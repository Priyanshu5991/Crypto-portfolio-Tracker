import requests # type: ignore

def get_token_prices(symbols):
    ids = ','.join(symbols)
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
    res = requests.get(url)
    data = res.json()
    return {sym: data.get(sym, {}).get('usd', 0) for sym in symbols}

def get_wallet_data(wallet_address):
    tokens = [
        {"symbol": "ethereum", "balance": 1.8},
        {"symbol": "tether", "balance": 800}
    ]
    prices = get_token_prices([t["symbol"] for t in tokens])
    for t in tokens:
        t["price_usd"] = prices.get(t["symbol"], 0)
    total_value = sum(t["balance"] * t["price_usd"] for t in tokens)
    return {"wallet": wallet_address, "tokens": tokens, "total_value_usd": total_value}
