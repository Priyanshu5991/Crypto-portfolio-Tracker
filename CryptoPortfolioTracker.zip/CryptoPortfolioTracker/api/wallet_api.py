from flask import Blueprint, request, jsonify # type: ignore
from services.wallet_service import get_wallet_data

wallet_api = Blueprint('wallet_api', __name__)

@wallet_api.route('', methods=['POST'])
def get_wallet_info():
    wallet_address = request.json.get('wallet')
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    try:
        data = get_wallet_data(wallet_address)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
