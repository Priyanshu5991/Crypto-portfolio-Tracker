def get_price_chart_data(symbol):
    return {
        "symbol": symbol,
        "prices": [3200, 3220, 3190, 3250, 3300, 3350, 3400],
        "labels": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    }
