from flask import Blueprint, jsonify # type: ignore
from services.price_service import get_price_chart_data

price_api = Blueprint('price_api', __name__)

@price_api.route('/<symbol>', methods=['GET'])
def get_price(symbol):
    try:
        return jsonify(get_price_chart_data(symbol))
    except Exception as e:
        return jsonify({'error': str(e)}), 500
