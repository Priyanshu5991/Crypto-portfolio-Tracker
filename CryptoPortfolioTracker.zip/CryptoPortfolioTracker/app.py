from flask import Flask, render_template
from flask_cors import CORS # type: ignore
from api.price_api import price_api
from api.wallet_api import wallet_api

app = Flask(__name__)
CORS(app)

# Register Blueprints
app.register_blueprint(price_api, url_prefix="/api/price")
app.register_blueprint(wallet_api, url_prefix="/api/wallet")

@app.route('/')
def home():
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True)
